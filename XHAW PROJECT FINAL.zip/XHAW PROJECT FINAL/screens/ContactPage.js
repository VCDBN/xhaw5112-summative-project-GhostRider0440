  import React,{ useState,useRef, useEffect } from 'react';

import { View, Text, TextInput, Button, StyleSheet,TouchableOpacity,Alert,Animated } from 'react-native';



 

const ContactPage = ({ navigation }) => {


  // Submit button animation //
    const [animation, setAnimation] = useState(new Animated.Value(0));

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(animation, {
        toValue: 1,
        duration: 500,
        useNativeDriver: false,
      }),
      Animated.timing(animation, {
        toValue: 0,
        duration: 500,
        useNativeDriver: false,
      }),
    ]).start();
    
  };

  const animatedStyles = {
    transform: [
      {
        scale: animation.interpolate({
          inputRange: [0, 1],
          outputRange: [1, 2],
        }),
      },
    ],
    opacity: animation.interpolate({
      inputRange: [0, 1],
      outputRange: [1, 0],
    }),
  };
// Submit button animation //


  const shakeAnimation = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
      Animated.timing(shakeAnimation, { toValue: 10, duration: 1000, useNativeDriver: true }),
      Animated.timing(shakeAnimation, { toValue: -0, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, [shakeAnimation]);





  const [NameInput, setNameInput] = useState();
  const [EmailInput, setEmailInput] = useState('');
  const [PhoneInput, setPhoneInput] = useState('');
  const [AddressInput, setAddressInput] = useState('');
  const [MessageInput, setMessageInput] = useState('');

  const handleSubmit = () => {
    if (NameInput.trim() === '') {
      Alert.alert("Name input is empty");
    }

    if (EmailInput.trim() === '') {
      Alert.alert("Email input is empty");
    }

    if (PhoneInput.trim() === '') {
      Alert.alert("Phone number input is empty");
    }

    if (AddressInput.trim() === '') {
      Alert.alert("Address input is empty");
    }

    if (MessageInput.trim() === '') {
      Alert.alert("Please enter your message");
    } else {
      Alert.alert("Your message has been sent");
    }
  };

  

 

  return (

    <View style={styles.container}>

        <Animated.Text style={{ transform: [{ translateX: shakeAnimation.interpolate({ inputRange: [-1, 1], outputRange: [-10, 10] }) }] }}>
      <Text style={styles.header}>Contact Us</Text>
    </Animated.Text>



    <View style={styles.inputfields}>  

      <TextInput

        value={NameInput}

        style={styles.input}

        placeholder="Name"

        placeholderTextColor="black"

      />

      <TextInput

        value={EmailInput}

        style={styles.input}

        placeholder="Email"

        placeholderTextColor="black"

      />

      <TextInput

        value={PhoneInput}

        style={styles.input}

        placeholder="Phone Number"

        placeholderTextColor="black"

        keyboardType="phone-pad"

      />

      <TextInput

        value={AddressInput}

        style={styles.input}

        placeholder="Physical Address"

        placeholderTextColor="black"

      />

      <TextInput

        value={MessageInput}

        style={styles.textarea}

        placeholder="Message"

        multiline={true}

        numberOfLines={2}

        placeholderTextColor="black"

      />
    
    </View>  


 
    <TouchableOpacity onPress={handlePress}>
      <Animated.View style={[{left:120,top:50, width: 100, height: 50, backgroundColor: '#426B1F',borderRadius:10, }, animatedStyles]}>
        <Text style={styles.SubmitButtonTxt}> Submit </Text>
      </Animated.View>
    </TouchableOpacity>

    </View>

  );

};

 


 

const styles = StyleSheet.create({

  container: {

    flex: 1,

    padding: 25,

    backgroundColor: '#e5f3e3',

  },

  header: {

    fontSize: 30,

    fontWeight: 'bold',

    marginBottom: 20,

    textAlign: 'center',

    color: 'white',

    padding:8,

    backgroundColor:'#426B1F',

    borderRadius:10,
  },

  inputfields:{
    top:50,
  },

  input: {

    height: 40,

    borderColor: '#426B1F',

    borderRadius:10,

    borderWidth: 3,

    marginBottom: 15,

    paddingLeft: 10,

    backgroundColor: 'white',

    color: 'black',

    placeholderTextColor:'#037e5d',

  },

  textarea: {

    height: 100,

    borderColor: '#426B1F',

    borderWidth: 3,

    borderRadius:10,

    marginBottom: 15,

    paddingLeft: 10,

    backgroundColor: 'white',

    color: 'black',
    placeholderTextColor:'#037e5d',

  },

  SubmitButton:{
    backgroundColor:'#426B1F',
    borderRadius:10,
    width:100,
    height:50,
    top:1,
    left:-20,
    color:"white",
    fontSize:20,
  },
  SubmitButtonTxt:{
    color:'white',
    fontSize:25,
    padding:3,
    left:-20,
  },

});

 

export default ContactPage;