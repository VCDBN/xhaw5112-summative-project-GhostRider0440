import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import { View, Text, StyleSheet, ScrollView, TouchableHighlight, Modal, Button,Alert,TouchableOpacity,Image} from 'react-native';
import { createNativeStackNavigator } from '../node_modules/@react-navigation/native-stack/lib/typescript/src';
import { NavigationContainer } from '../node_modules/@react-navigation/native/lib/typescript/src';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';


import ContactPage from './ContactPage'
import { createStackNavigator } from '../node_modules/@react-navigation/stack/lib/typescript/src';
 

const coursesData = [

  {

    name: 'First Aid',

    b1:'Wounds and bleeding',
    b2:'Burns and fractures',
    b3:'Emergency scene management',
    b4:'Cardio-Pulmonary Resuscitation (CPR)',
    b5:'Respiratory distress e.g., Choking, blocked airway',
    img:require('./gallary/first-aid-box.png'),

    fee: 1500,

    duration: '6 months',

    description: 'To provide first aid awareness and basic life support',

  },

  {

    name: 'Sewing',

    b1:'Types of stitches',
    b2:'Threading a sewing machine',
    b3:'Sewing buttons, zips, hems and seams',
    b4:'Alterations',
    b5:'Designing and sewing new garments',

    img:require('./CourseIcons/sewing.png'),

    fee: 1500,

    duration: '6 months',

    description: 'To provide alterations and new garment tailoring services',

  },

  {

    name: 'Landscaping',

    b1:'Indigenous and exotic plants and trees',
    b2:'Fixed structures (fountains, statues, benches, tables, built-in braai)',
    b3:'Balancing of plant and trees in a garden',
    b4:'Aesthetics of plant shapes and colours',
    b5:'Garden layout',

    img:require('./CourseIcons/gardening.png'),

    fee: 1500,

    duration: '6 months',

    description: 'To provide landscaping services for new and established gardens',

  },

  {

    name: 'Life Skills',

    b1:'Opening a bank account',
    b2:'Basic labour law (know your rights)',
    b3:'BBasic reading and writing literacy',
    b4:'Basic numeric literacy',

    img:require('./CourseIcons/life-insurance.png'),

    fee: 1500,

    duration: '6 months',

    description: 'To provide skills to navigate basic life necessities',

  },

  {

    name: 'Child Minding',

    b1:'birth to six-month old baby needs',
    b2:'seven-month to one year old needs',
    b3:'Toddler needs',
    b4:'Educational toys',

    img:require('./CourseIcons/maternity.png'),

    fee: 750,

    duration: '6 weeks',

    description: 'To provide basic child and baby care',

  },

  {

    name: 'Cooking',

    b1:'Nutritional requirements for a healthy body',
    b2:'Types of protein, carbohydrates and vegetables',
    b3:'Planning meals',
    b4:'Preparation and cooking of meals',

    img:require('./CourseIcons/cooking.png'),

    fee: 750,

    duration: '6 weeks',

    description: 'To prepare and cook nutritious family meals',

  },

  {

    name: 'Garden Maintenance',

    b1:'Water restrictions and the watering requirements of indigenous and exotic plants',
    b2:'Pruning and propagation of plants',
    b3:'Planting techniques for different plant types',

    img:require('./CourseIcons/gardening(1).png'),

    fee: 750,

    duration: '6 weeks',

    description: 'To provide basic knowledge of watering, pruning, and planting',

  },

  {

    name: 'Barista Training',

        b1:'Indigenous and exotic plants and trees',
    b2:'Fixed structures (fountains, statues, benches, tables, built-in braai)',
    b3:'Balancing of plant and trees in a garden',
    b4:'Aesthetics of plant shapes and colours',
    b5:'Garden layout',

    img:require('./CourseIcons/barista.png'),

    fee: 1000,

    duration: '6 weeks',

    description: 'To provide coffee preparation and barista skills',

  },

  {

    name: 'Computer Programming',

        b1:'Indigenous and exotic plants and trees',
    b2:'Fixed structures (fountains, statues, benches, tables, built-in braai)',
    b3:'Balancing of plant and trees in a garden',
    b4:'Aesthetics of plant shapes and colours',
    b5:'Garden layout',

    img:require('./CourseIcons/programming.png'),

    fee: 2000,

    duration: '6 months',

    description: 'To teach programming skills and software development',

  },

  {

    name: 'Digital Marketing',

        b1:'Indigenous and exotic plants and trees',
    b2:'Fixed structures (fountains, statues, benches, tables, built-in braai)',
    b3:'Balancing of plant and trees in a garden',
    b4:'Aesthetics of plant shapes and colours',
    b5:'Garden layout',

    img:require('./CourseIcons/bullhorn.png'),

    fee: 1000,

    duration: '6 weeks',

    description: 'To provide skills in online marketing and advertising',

  },

];

 

const CoursesPage = ({ navigation }) => {

  const [hovered, setHovered] = useState(styles.discountText);

  const handleHover = () => {
     Alert.alert("dded")
    setHovered(styles.discountText);
  };

  const handleLeave = () => {
    setHovered(styles.discountTextHover);
  };



  const [selectedCourses, setSelectedCourses] = useState(new Array(coursesData.length).fill(''));

  const [discount, setDiscount] = useState(0);

  const [selectedCourseIndex, setSelectedCourseIndex] = useState(null);

 

  useEffect(() => {

    const courseCount = selectedCourses.filter(course => course !== '').length;

    setDiscount(calculateDiscount(courseCount));

  }, [selectedCourses]);

 

  const calculateDiscount = (courseCount) => {

    if (courseCount === 1) return 0;

    if (courseCount === 2) return 5;

    if (courseCount === 3) return 10;

    return 15;

  };

 

  const handleCourseSelection = (index) => {

    setSelectedCourseIndex(index);

  };

  const [CoursePriceValue, setCoursePriceValue] = useState('550'); 

  const closeCourseDetails = () => {
    setSelectedCourseIndex(null);

  };





    const AddCoursePrice = () => {
    setCoursePriceValue('400')
     navigation.navigate('Cart', { CoursePriceValue })
      
  };

  return (

    

    <View style={styles.container}>

      <Text style={styles.header}>Courses and Discounts</Text>

      <ScrollView style={styles.courseList}>

        {coursesData.map((course, index) => (

          <TouchableHighlight

            key={index}

            underlayColor="#E0E0E0"

            onPress={() => handleCourseSelection(index)}

          >

            <View style={styles.courseCard}>

              <Text style={styles.courseName}>{course.name}</Text>

              <Image style={styles.CourseIcon} source={course.img} />

              <View style={styles.coursetexts}>
              <Text style={styles.courseFee}>Fee: R{course.fee}</Text>

              <Text style={styles.courseDuration}>{course.duration}</Text>
              </View>

            </View>

          </TouchableHighlight>

        ))}

      </ScrollView>

    <TouchableOpacity
        onMouseEnter={handleHover}
        onMouseLeave={handleLeave}
       onPress={() => navigation.navigate('Learn')}
      style={styles.CheckOutPage}
    >
      <Text style={styles.discountTextHover}>Check Out</Text>
            <Image
        style={styles.CheckOutImage}
        source={require('./gallary/shopping-cart1.png')}
      /> 
    </TouchableOpacity>


      <Modal

        visible={selectedCourseIndex !== null}

        animationType="slide"

        onRequestClose={closeCourseDetails}

      >

        <View style={styles.courseDetailsModal}>

          <Text style={styles.courseDetailsTitle}>{coursesData[selectedCourseIndex]?.name}</Text>

           <Image style={styles.CourseViewIcon} source={coursesData[selectedCourseIndex]?.img} />

          <Text style={styles.courseDetailsDescription}>

            {coursesData[selectedCourseIndex]?.description}

          </Text>


          <Text style={styles.Courswbullets}> -{coursesData[selectedCourseIndex]?.b1}</Text>
          <Text style={styles.Courswbullets}> -{coursesData[selectedCourseIndex]?.b2}</Text>
          <Text style={styles.Courswbullets}> -{coursesData[selectedCourseIndex]?.b3}</Text>
          <Text style={styles.Courswbullets}> -{coursesData[selectedCourseIndex]?.b4}</Text>
          <Text style={styles.Courswbullets}> -{coursesData[selectedCourseIndex]?.b5}</Text>


          <Text style={styles.courseDetailsFee}>
          
            Fee: R{coursesData[selectedCourseIndex]?.fee}

          </Text>
          <Text> added price: {coursesData[selectedCourseIndex]?.fee}</Text>
          
          <TouchableHighlight

            style={styles.AddButton}

            underlayColor=""

            onPress={AddCoursePrice}

          >

            <Text style={styles.closeButtonText}>Add Course</Text>

          </TouchableHighlight>


          <TouchableHighlight

            style={styles.closeButton}

            underlayColor=""

            onPress={closeCourseDetails}

          >

            <Text style={styles.closeButtonText}>Close</Text>

          </TouchableHighlight>

        </View>

      </Modal>

    </View>

  );

};


const styles = StyleSheet.create({

  container: {

    flex: 1,

    padding: 20,

    backgroundColor: '#e5f3e3', // Light green background color

  },

  header: {

    fontSize: 24,

    fontWeight: 'bold',

    height:80,
    width:300,
    padding:10,

    marginBottom: 20,

    color: 'white', // Dark green text color

    backgroundColor:'#426B1F',

    borderRadius:10,

  },

  courseList: {

    marginBottom: 20,

  },

  courseCard: {
    borderWidth:4,
    height:100,
    padding:10,
    borderColor: '#426B1F',
    backgroundColor: '#fff', // Light green card background color

   // padding: 15,

    borderRadius: 10,

    marginBottom: 10,

  },

  courseName: {

    fontSize: 20,

    fontWeight: 'bold',

    color: '#037e5d', // Dark green text color

  },

  courseFee: {


    fontSize: 16,

    color: '#333', // Dark gray text color

  },

  courseDuration: {

    fontSize: 16,

  },

  discountText: {

    fontSize: 18,

    fontWeight: 'bold',

    color: 'white', // Dark green text color

    backgroundColor:'#037e5d',
    padding:10,
    width:150,
    borderRadius:10,

  },
    discountTextHover: {

    fontSize: 18,

    fontWeight: 'bold',

    color: 'white', // Dark green text color

    backgroundColor:'#037e5d',
    padding:10,
    width:150,
    borderRadius:10,
    borderColor:'black',
    borderWidth:2,

  },
  CheckOutImage:{
    width:30,
    height:30,
    top:-40,
    left:110,
  },

  courseDetailsModal: {

    flex: 1,

    justifyContent: 'center',

    padding: 20,

    backgroundColor: 'white', // White modal background color

  },

  courseDetailsTitle: {
    left:110,

    fontSize: 24,

    fontWeight: 'bold',

    marginBottom: 20,

    color: '#037e5d', // Dark green text color

  },

  courseDetailsDescription: {

    fontSize: 16,

    marginBottom: 10,

    color: '#333', // Dark gray text color

  },

  courseDetailsFee: {

    fontSize: 16,

    marginBottom: 10,

    color: '#333', // Dark gray text color

  },

  closeButton: {

    backgroundColor: '#d6f7e2', // Light green button background color

    padding: 10,

    borderRadius: 10,

  },

  closeButtonText: {

    fontSize: 16,

    textAlign: 'center',

    color: '#037e5d', // Dark green text color

  },

  AddButton: {

    backgroundColor: '#d6f7e2', // Light green button background color

    padding: 10,

    margin:10,

    borderRadius: 10,

  },
  CourseIcon:{
    
    width:70,
    height:70,
    top:-27,
    left:210,
    
  },
  coursetexts:{
    top:-70,
  },
  CourseViewIcon:{
    height:100,
    width:100,
    left:110,
  },
  Courswbullets:{
    padding:10,
  }

});



export default CoursesPage;