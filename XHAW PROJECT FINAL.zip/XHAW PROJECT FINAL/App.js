import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image } from 'react-native';
import TESTING from './screens/TESTING'
import ContactPage from './screens/ContactPage'
import courseData from './screens/coursesData'
import Cart from './screens/Cart'
//import { Screen } from 'react-native-screens';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainNavigator() {
  return (
<Tab.Navigator>
    <Tab.Screen
    name="Home"
    component={TESTING}
    options={{
   tabBarIcon: ({ focused, color, size }) => (
   <Image
       source={require('./home.png')}
     style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Contact"
        component={ContactPage}
        options={{
       tabBarIcon: ({ focused, color, size }) => (
         <Image
        source={require('./user.png')}
        style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Courses"
        component={courseData}
       options={{
       tabBarIcon: ({ focused, color, size }) => (
            <Image
        source={require('./shopping-cart.png')}
       style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Check out"
        component={Cart}
       options={{
       tabBarIcon: ({ focused, color, size }) => (
            <Image
        source={require('./wallet.png')}
       style={{ width: size, height: size, tintColor: color }}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
   <NavigationContainer>
 <Stack.Navigator>
    <Stack.Screen
    name="Main"    component={MainNavigator}
     options={{ headerShown: false }}
     />
      </Stack.Navigator>
    </NavigationContainer>
  );
}



