import { Text, SafeAreaView,TouchableOpacity, StyleSheet,Alert } from 'react-native';

// You can import supported modules from npm

export default function App() {

    const closeCourseDetails = () => {
    Alert.alert("reerf")

  };
  return (
    <SafeAreaView style={styles.container}>
          <TouchableOpacity style={styles.ContinueButton} onPress={closeCourseDetails}>
       <Text style={styles.ContinueButtonTxt}>Continue to pdayment</Text>
 
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
